<?php
// ct.php – CT Branch User Dashboard
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "user" || $_SESSION["branch"] !== "ME") {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>CT User Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../CSS/ct.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
</head>

<body>

<h1>🎓 ME Teacher Dashboard</h1>
<div class="username">
    (<?= htmlspecialchars($_SESSION["username"]) ?>)
</div>

<div class="dashboard">

    <a href="ME/MEuserOrder.php" class="card">
        <img src="https://cdn-icons-png.flaticon.com/512/3081/3081559.png">
        <span>📦 Request Component</span>
    </a>
    <a href="ME/MEuserView.php" class="card">
        <img src="https://cdn-icons-png.flaticon.com/512/3081/3081559.png">
        <span>📦 Request View</span>
    </a>
    <a href="ME/ME_report_issue.php" class="card">
        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828843.png">
        <span>📝 Report Issue</span>
    </a>

    <a href="ME/ME_report_hardware.php" class="card">
        <img src="https://cdn-icons-png.flaticon.com/512/893/893237.png">
        <span>💻 Hardware Issue</span>
    </a>

    <a href="ME/ME_report_stock.php" class="card">
        <img src="https://cdn-icons-png.flaticon.com/512/1040/1040230.png">
        <span>📦 Stock View</span>
    </a>

    <a href="../index.php" class="card logout">
        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828490.png">
        <span>🚪 Logout</span>
    </a>

</div>



</body>
</html>