<?php
// ================= SESSION ================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "main_admin") {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Owner Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="CSS/pri/main_admins.css">
</head>

<body>

<!-- ☰ MENU BUTTON -->
<div class="menu-btn" onclick="toggleMenu()">☰</div>

<!-- HIDDEN MENU -->
<div id="menuBox" class="menu-box">
    <a href="main_admin.php">🏠 Home</a>
    <a href="SRS & REPORT WITH PPT/instruction.php">📘 Instruction</a>
    <a href="SRS & REPORT WITH PPT/srs.php" target="_blank">📄 SRS</a>
    <a href="SRS & REPORT WITH PPT/ppt.php" target="_blank">📊 PPT</a>
    <a href="SRS & REPORT WITH PPT/report.php" target="_blank">📑 Report</a>
</div>

<h1>🚀 Owner Dashboard</h1>
<div class="username">
    (<?= htmlspecialchars($_SESSION["username"]) ?>)
</div>

<div class="dashboard">

<a href="PRINCIPAL/addstudent.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/1828/1828817.png">
    <span>🧑‍🎓 Add Student</span>
</a>

<a href="PRINCIPAL/add_users.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/1828/1828817.png">
    <span>➕ Add Teachers</span>
</a>

<a href="PRINCIPAL/add_dept_admin.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/992/992651.png">
    <span>➕ Add Dept Hod's</span>
</a>

<a href="PRINCIPAL/view_students.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/1077/1077063.png">
    <span>👁 View Students</span>
</a>

<a href="PRINCIPAL/view_users.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/1077/1077063.png">
    <span>👁 View Teachers</span>
</a>

<a href="PRINCIPAL/view_dept_admin.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/847/847969.png">
    <span>👁 View Dept Hod's</span>
</a>

<a href="PRINCIPAL/View_report_All.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/2099/2099058.png">
    <span>📨 View Reports</span>
</a>

<a href="PRINCIPAL/order_components.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/893/893237.png">
    <span>🖥️ Hardware Orders</span>
</a>

<a href="PRINCIPAL/rmip.php" class="card logout">
    <img src="https://cdn-icons-png.flaticon.com/512/2913/2913465.png">
    <span>🔓 Clear Login Blocks</span>
</a>

<a href="PRINCIPAL/PVstock.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/1040/1040230.png">
    <span>📦 Manage Stock</span>
</a>

<a href="PRINCIPAL/Pstock.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/992/992651.png">
    <span>➕ Add Stock</span>
</a>

<a href="PRINCIPAL/supply_stock.php" class="card">
    <img src="https://cdn-icons-png.flaticon.com/512/3082/3082031.png">
    <span>📦 Supply Stock</span>
</a>

<a href="logout.php" class="card logout">
    <img src="https://cdn-icons-png.flaticon.com/512/1828/1828490.png">
    <span>🚪 Logout</span>
</a>

</div>

<!-- JS -->
<script>
function toggleMenu() {
    document.getElementById("menuBox").classList.toggle("show");
}

// CLICK OUTSIDE CLOSE
document.addEventListener("click", function(e) {
    let menu = document.getElementById("menuBox");
    let btn = document.querySelector(".menu-btn");

    if (!menu.contains(e.target) && !btn.contains(e.target)) {
        menu.classList.remove("show");
    }
});
</script>

</body>
</html>