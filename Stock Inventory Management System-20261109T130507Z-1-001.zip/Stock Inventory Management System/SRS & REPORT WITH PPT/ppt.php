<?php
$file = "Presentation 3.pdf";

if (file_exists($file)) {
    header("Content-Type: application/vnd.openxmlformats-officedocument.presentationml.presentation");
    header("Content-Disposition: attachment; filename=\"" . basename($file) . "\"");
    header("Content-Length: " . filesize($file));
    readfile($file);
    exit;
} else {
    echo "File not found!";
}
?>