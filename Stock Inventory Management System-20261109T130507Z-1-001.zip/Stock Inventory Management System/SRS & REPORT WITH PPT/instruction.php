<?php
$file = "instruction.pdf";

if (file_exists($file)) {
    header("Content-Type: application/pdf");
    header("Content-Disposition: inline; filename='$file'");
    header("Content-Transfer-Encoding: binary");
    header("Accept-Ranges: bytes");
    readfile($file);
    exit;
} else {
    echo "PDF file not found!";
}
?>