<?php
$file = "srs__smart_boys_ (1).pdf";

if (file_exists($file)) {
    header("Content-Type: application/pdf");
    header("Content-Disposition: inline; filename=\"" . basename($file) . "\"");
    header("Content-Length: " . filesize($file));
    readfile($file);
    exit;
} else {
    echo "File not found!";
}
?>