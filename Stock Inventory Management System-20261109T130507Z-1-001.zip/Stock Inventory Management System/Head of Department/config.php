<?php
$servername = "localhost";  // XAMPP default
$dbusername = "root";       // XAMPP default username
$dbpassword = "";           // XAMPP default has no password
$dbname = "inventory";      // Your database name

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}
?>
