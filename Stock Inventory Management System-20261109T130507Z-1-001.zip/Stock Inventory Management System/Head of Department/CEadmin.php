<?php
// ================= SESSION SECURITY =================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    empty($_SESSION["username"]) ||
    empty($_SESSION["role"]) ||
    empty($_SESSION["branch"]) ||
    $_SESSION["role"] !== "branch_admin" ||
    $_SESSION["branch"] !== "CE"
) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CE HOD Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/CEadmin.css">
</head>
<body>

<nav>
    <h2>CE HOD Dashboard</h2>
    <button class="toggle-theme" onclick="toggleTheme()">🌗 Toggle Theme</button>
</nav>

<div class="container">
    <h1>Welcome CE HOD (<?= htmlspecialchars($_SESSION['username']); ?>)</h1>
    <div class="datetime" id="datetime"></div>

    <div class="button-grid">

        <a href="CE/CE_ordering_components.php" class="box-btn">
            <div class="icon">🛒</div>
            <p>Order New Components</p>
        </a>

        <a href="CE/view_stock.php" class="box-btn">
                <div class="icon">🧾</div>
                <p>Place Stock Order</p>
        </a>

        <a href="CE/CE_view_user_issues.php" class="box-btn">
            <div class="icon">🛠</div>
            <p>View Order Track</p>
        </a>

        <a href="CE/CE_report_to_main_admin.php" class="box-btn">
            <div class="icon">📨</div>
            <p>Report to Main Admin</p>
        </a>

        <a href="CE/complaint_status.php" class="box-btn">
            <div class="icon">📋</div>
            <p>COMPLAINT STATUS</p>
        </a>

        <a href="CE/CE_supply_components.php" class="box-btn">
            <div class="icon">📦</div>
            <p>Supply Hardware</p>
        </a>

        <a href="CE/techers_components.php" class="box-btn">
            <div class="icon">📦</div>
            <p>View Order Components</p>
        </a>


        <a href="../logout.php" class="box-btn logout">
            <div class="icon">🚪</div>
            <p>Logout</p>
        </a>

    </div>
</div>

<script>
// Live Date-Time
function updateTime() {
    const now = new Date();
    document.getElementById("datetime").innerText = now.toLocaleString();
}
setInterval(updateTime, 1000);
updateTime();

// Theme toggle
function toggleTheme() {
    document.body.classList.toggle("dark");
}
</script>

</body>
</html>