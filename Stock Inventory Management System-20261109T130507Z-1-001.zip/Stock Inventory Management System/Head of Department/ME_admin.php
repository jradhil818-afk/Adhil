<?php
// ================= SESSION SECURITY =================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    empty($_SESSION["username"]) ||
    empty($_SESSION["role"]) ||
    empty($_SESSION["branch"]) ||
    $_SESSION["role"] !== "branch_admin" ||
    $_SESSION["branch"] !== "ME"
) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ME HOD Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/ME_admin.css">
</head>
<body>

<nav>
    <h2>ME HOD Dashboard</h2>
    <button class="toggle-theme" onclick="toggleTheme()">🌗 Toggle Theme</button>
</nav>

<div class="container">
    <h1>Welcome ME HOD (<?= htmlspecialchars($_SESSION['username']); ?>)</h1>
    <div class="datetime" id="datetime"></div>

    <div class="button-grid">
        <a href="ME/ME_ordering_components.php" class="box-btn">
            <div class="icon">🛒</div>
            <p>Order New Components</p>
        </a>
        <a href="ME/ME_view_stock.php" class="box-btn">
            <div class="icon">🧾</div>
            <p>Place Stock Order</p>
        </a>
        <a href="ME/ME_report_to_main_admin.php" class="box-btn">
            <div class="icon">📨</div>
            <p>Report to Main Admin</p>
        </a>

        <a href="ME/ME_view_user_issues.php" class="box-btn">
            <div class="icon">🛠</div>
            <p>View Order Track</p>
        </a>

         </a>  
            <a href="ME/complaint_status.php" class="box-btn">
            <div class="icon">📋</div>
            <p>COMPLAINT STATUS</p>
        </a>

        <a href="ME/supply_components.php" class="box-btn">
            <div class="icon">📦</div>
            <p>Supply Components</p>
        </a>

       </a>
        <a href="ME/techers_components.php" class="box-btn">
            <div class="icon">📦</div>
            <p>View Order Components</p>
        </a>

        <a href="../logout.php" class="box-btn logout">
            <div class="icon">🚪</div>
            <p>Logout</p>
        </a>

    </div>
</div>

<script>
// Live Date-Time
function updateTime() {
    const now = new Date();
    document.getElementById("datetime").innerText = now.toLocaleString();
}
setInterval(updateTime, 1000);
updateTime();

// Theme toggle
function toggleTheme() {
    document.body.classList.toggle("dark");
}
</script>

</body>
</html>