<?php
session_start();
if (!isset($_SESSION["username"]) || $_SESSION["role"] !== "branch_admin" || $_SESSION["branch"] !== "EE") {
    header("Location: index.php");
    exit();
}
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EE Hod's Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/CTadmin.css">
</head>
<body>

    <nav>
        <h2>EE Hod's Dashboard</h2>
        <button class="toggle-theme" onclick="toggleTheme()">🌗 Toggle Theme</button>
    </nav>

    <div class="container">
        <h1>Welcome EE Hod's (<?= htmlspecialchars($_SESSION['username']); ?>)</h1>
        <div class="datetime" id="datetime"></div>

        <!-- Box Style Buttons -->
        <div class="button-grid">
            <a href="EE/ordering_components.php" class="box-btn">
                <div class="icon">🛒</div>
                <p>Order New Components</p>
            </a>
            
            </a>
            <a href="EE/EE_view_user_issues.php" class="box-btn">
                <div class="icon">🛠</div>
                <p>View Order Track</p>
            </a>

            <a href="EE/report_to_main_admin.php" class="box-btn">
                <div class="icon">📨</div>
                <p>Report to Main Admin</p>
            </a> 

            <a href="EE/complaint_status.php" class="box-btn">
                <div class="icon">📋</div>
                <p>COMPLAINT STATUS</p>
            </a>

            <a href="EE/view_stock.php" class="box-btn">
                <div class="icon">🧾</div>
                <p>Place Stock Order</p>
            </a>
                
            <a href="EE/supply_components.php" class="box-btn">
                <div class="icon">📦</div>
                <p>Supply Components</p>
            </a>
            </a>
            <a href="EE/techers_components.php" class="box-btn">
                <div class="icon">📦</div>
                <p>View Order Components</p>
            </a>

            <a href="../logout.php" class="box-btn logout">
                <div class="icon">🚪</div>
                <p>Logout</p>
            </a>
        </div>
    </div>

    <script>
        // Live Date-Time
        function updateTime() {
            const now = new Date();
            const datetimeEl = document.getElementById("datetime");
            datetimeEl.innerText = now.toLocaleString();
        }
        setInterval(updateTime, 1000);
        updateTime();

        // Theme toggle
        function toggleTheme() {
            document.body.classList.toggle("dark");
        }
    </script>

</body>
</html>
