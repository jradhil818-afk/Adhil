<?php
declare(strict_types=1);
session_start();
error_reporting(E_ALL);
ini_set('display_errors', '1');

// DB Connection
$conn = new mysqli("localhost", "root", "", "inventory");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

// CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function sanitize_input(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function get_failed_attempts(mysqli $conn, string $username, string $ip): int {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE username=? AND ip_address=? AND attempt_time > (NOW() - INTERVAL 25 MINUTE)");
    $stmt->bind_param("ss", $username, $ip);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count;
}

function record_failed_attempt(mysqli $conn, string $username, string $ip): void {
    $stmt = $conn->prepare("INSERT INTO login_attempts (username, ip_address) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $ip);
    $stmt->execute();
    $stmt->close();
}

function clear_attempts(mysqli $conn, string $username, string $ip): void {
    $stmt = $conn->prepare("DELETE FROM login_attempts WHERE username=? AND ip_address=?");
    $stmt->bind_param("ss", $username, $ip);
    $stmt->execute();
    $stmt->close();
}

function attempt_login(mysqli $conn, string $username, string $password, string $branch): ?array {
    $roles = [
        'main_admin' => [
            'query' => "SELECT * FROM main_admin WHERE username=?",
            'params' => ['s' => [$username]],
            'redirect' => 'main_admin.php'
        ],
        'branch_admin' => [
            'query' => "SELECT * FROM branch_admin WHERE username=? AND branch=?",
            'params' => ['ss' => [$username, $branch]],
            'redirects' => [
                'CT'=>'Head of Department/CTadmin.php',
                'ME'=>'Head of Department/ME_admin.php',
                'CE'=>'Head of Department/CEadmin.php',
                'EE'=>'Head of Department/EEadmin.php',
                'default'=>'dept_admin.php'
            ]
        ],
        'user' => [
            'query' => "SELECT * FROM user WHERE username=? AND branch=?",
            'params' => ['ss' => [$username, $branch]],
            'redirects' => [
                'CT'=>'TEACHERS/ct.php',
                'ME'=>'TEACHERS/me.php',
                'CE'=>'TEACHERS/ce.php',
                'EE'=>'TEACHERS/ee.php',
                'default'=>'user_dashboard.php'
            ]
        ],
        'student' => [
            'query' => "SELECT * FROM students WHERE username=? AND branch=?",
            'params' => ['ss' => [$username, $branch]],
            'redirects' => [
                'CT'=>'STUDENTS/CT/ct_student.php',
                'ME'=>'STUDENTS/ME/me_student.php',
                'CE'=>'STUDENTS/CE/ce_student.php',
                'EE'=>'STUDENTS/EE/ee_student.php',
                'default'=>'student_dashboard.php'
            ]
        ]
    ];

    foreach ($roles as $role => $data) {
        $stmt = $conn->prepare($data['query']);
        $types = key($data['params']);
        $stmt->bind_param($types, ...$data['params'][$types]);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;

            if ($role !== 'main_admin') {
                $_SESSION['branch'] = $branch;
                $redirect = $data['redirects'][$branch] ?? $data['redirects']['default'];
            } else {
                $redirect = $data['redirect'];
            }

            return ['redirect' => $redirect];
        }
    }
    return null;
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token";
    } else {
        $username = sanitize_input($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $branch = sanitize_input($_POST['branch'] ?? '');
        $ip = $_SERVER['REMOTE_ADDR'];

        $attempts = get_failed_attempts($conn, $username, $ip);

        if ($attempts >= 7) {
            $error = "Too many attempts. Try after 25 minutes.";
        } else {
            $login = attempt_login($conn, $username, $password, $branch);
            if ($login) {
                clear_attempts($conn, $username, $ip);
                header("Location: " . $login['redirect']);
                exit();
            } else {
                record_failed_attempt($conn, $username, $ip);
                $error = "Invalid login";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inventory Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="CSS/index.css">
</head>

<body>

<!-- Navbar -->
<nav class="navbar">
  <div class="logo">📦 Inventory System</div>
  <div class="menu-icon" onclick="toggleMenu()">☰</div>
  <ul class="nav-links" id="navMenu">
    <li><a href="index.php">Home</a></li>
    <li><a href="informations/about.php">About</a></li>
    <li><a href="informations/contact.php">Contact</a></li>
  </ul>
</nav>

<!-- Login Card -->
<div class="login-card">
  <h2>🔐 Inventory Login</h2>

  <?php if (!empty($error)) echo "<div class='error-box'>$error</div>"; ?>

  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

    <div class="form-group">
      <label>Username</label>
      <input type="text" name="username" required>
    </div>

    <div class="form-group password-toggle">
      <label>Password</label>
      <input type="password" name="password" id="password" required>
      <span onclick="togglePassword()">👁️</span>
    </div>

    <div class="form-group">
      <label>Branch</label>
      <select name="branch" required>
        <option value="">Select</option>
        <option value="CT">CT</option>
        <option value="ME">ME</option>
        <option value="CE">CE</option>
        <option value="EE">EE</option>
      </select>
    </div>

    <button type="submit">Login</button>
  </form>
</div>

<script>
function toggleMenu() {
  document.getElementById("navMenu").classList.toggle("active");
}

document.addEventListener("click", function(event) {
  const menu = document.getElementById("navMenu");
  const icon = document.querySelector(".menu-icon");

  if (!menu.contains(event.target) && !icon.contains(event.target)) {
    menu.classList.remove("active");
  }
});

/* ✅ PASSWORD TOGGLE FIX */
function togglePassword() {
  const password = document.getElementById("password");
  const icon = document.querySelector(".password-toggle span");

  if (password.type === "password") {
    password.type = "text";
    icon.textContent = "🙈";
  } else {
    password.type = "password";
    icon.textContent = "👁️";
  }
}
</script>

</body>
</html>